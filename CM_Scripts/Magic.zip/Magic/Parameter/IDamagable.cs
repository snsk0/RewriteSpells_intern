namespace CM.Magic.Parameter
{
    public interface IDamagable
    {
        public void Damage(float damage);
    }
}
