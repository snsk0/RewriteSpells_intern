using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CM.Magic.Temp
{
    public class EnemyMp : MonoBehaviour, IMana
    {
        public bool Reduce(float value)
        {
            return true;
        }
    }
}
